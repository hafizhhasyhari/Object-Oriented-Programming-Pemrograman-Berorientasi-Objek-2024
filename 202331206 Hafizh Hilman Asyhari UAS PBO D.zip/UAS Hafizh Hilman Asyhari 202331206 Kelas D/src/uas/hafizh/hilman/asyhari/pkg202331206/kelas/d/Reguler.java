/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uas.hafizh.hilman.asyhari.pkg202331206.kelas.d;

/**
 * Subclass Reguler
 */
public class Reguler extends Mahasiswa {
        // Nama : Hafizh Hilman Asyhari
        // Kelas : D
        // Prodi : S1 Teknik Informatika
        // NIM : 202331206
        // Tanggal : 18 Januari 2025
        // UAS Pemrograman Berorientasi Objek
    
    private float nilaiKehadiran;
    private float nilaiPresentasi;
    private float nilaiArgumentasi;

    // Setter untuk atribut khusus Reguler
    public void setNilaiKehadiran(float nilaiKehadiran) {
        this.nilaiKehadiran = nilaiKehadiran;
    }

    public void setNilaiPresentasi(float nilaiPresentasi) {
        this.nilaiPresentasi = nilaiPresentasi;
    }

    public void setNilaiArgumentasi(float nilaiArgumentasi) {
        this.nilaiArgumentasi = nilaiArgumentasi;
    }

    // Implementasi method abstrak hitungNilaiAkhir
    @Override
    public float hitungNilaiAkhir() {
        return (0.2f * nilaiKehadiran) + (0.3f * nilaiPresentasi) + (0.5f * nilaiArgumentasi);
    }
}