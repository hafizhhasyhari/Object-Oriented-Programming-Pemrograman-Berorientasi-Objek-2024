/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package uas.hafizh.hilman.asyhari.pkg202331206.kelas.d;

/**
 * Main Class
 */
public class Main {
    public static void main(String[] args) {
        // Nama : Hafizh Hilman Asyhari
        // Kelas : D
        // Prodi : S1 Teknik Informatika
        // NIM : 202331206
        // Tanggal : 18 Januari 2025
        // UAS Pemrograman Berorientasi Objek
        
        
        // Data mahasiswa reguler
        Reguler mhsReguler1 = new Reguler();
        mhsReguler1.setMahasiswa("2023311209", "Tasya", "Teknik Informatika");
        mhsReguler1.setNilaiKehadiran(85);
        mhsReguler1.setNilaiPresentasi(90);
        mhsReguler1.setNilaiArgumentasi(80);

        Reguler mhsReguler2 = new Reguler();
        mhsReguler2.setMahasiswa("202331206", "Hafizh Hilman Asyhari", "Teknik Informatika");
        mhsReguler2.setNilaiKehadiran(88);
        mhsReguler2.setNilaiPresentasi(92);
        mhsReguler2.setNilaiArgumentasi(85);

        Reguler mhsReguler3 = new Reguler();
        mhsReguler3.setMahasiswa("202332001", "Yanti", "Sistem Informasi");
        mhsReguler3.setNilaiKehadiran(80);
        mhsReguler3.setNilaiPresentasi(85);
        mhsReguler3.setNilaiArgumentasi(75);

        Reguler mhsReguler4 = new Reguler();
        mhsReguler4.setMahasiswa("202344009", "Leonardo", "Teknik Robotika dan Kecerdasan Buatan");
        mhsReguler4.setNilaiKehadiran(90);
        mhsReguler4.setNilaiPresentasi(95);
        mhsReguler4.setNilaiArgumentasi(88);

        // Data mahasiswa karyawan
        Karyawan mhsKaryawan1 = new Karyawan();
        mhsKaryawan1.setMahasiswa("202332012", "Kathleen", "Teknik Nuklir");
        mhsKaryawan1.setNilaiPembimbing(75);
        mhsKaryawan1.setNilaiPengetahuan(80);
        mhsKaryawan1.setNilaiKeterampilan(85);

        Karyawan mhsKaryawan2 = new Karyawan();
        mhsKaryawan2.setMahasiswa("202332066", "Zulkarnain", "Sistem Informasi");
        mhsKaryawan2.setNilaiPembimbing(70);
        mhsKaryawan2.setNilaiPengetahuan(78);
        mhsKaryawan2.setNilaiKeterampilan(80);

        // Output data mahasiswa reguler
        System.out.println("Data Mahasiswa Reguler:");
        System.out.println(mhsReguler1.getMahasiswa());
        System.out.println("Nilai Akhir: " + mhsReguler1.hitungNilaiAkhir());
        System.out.println("Grade: " + mhsReguler1.hitungGrade());

        System.out.println("\n============================\n");

        System.out.println(mhsReguler2.getMahasiswa());
        System.out.println("Nilai Akhir: " + mhsReguler2.hitungNilaiAkhir());
        System.out.println("Grade: " + mhsReguler2.hitungGrade());

        System.out.println("\n============================\n");

        System.out.println(mhsReguler3.getMahasiswa());
        System.out.println("Nilai Akhir: " + mhsReguler3.hitungNilaiAkhir());
        System.out.println("Grade: " + mhsReguler3.hitungGrade());

        System.out.println("\n============================\n");

        System.out.println(mhsReguler4.getMahasiswa());
        System.out.println("Nilai Akhir: " + mhsReguler4.hitungNilaiAkhir());
        System.out.println("Grade: " + mhsReguler4.hitungGrade());

        System.out.println("\n============================\n");

        // Output data mahasiswa karyawan
        System.out.println("Data Mahasiswa Karyawan:");
        System.out.println(mhsKaryawan1.getMahasiswa());
        System.out.println("Nilai Akhir: " + mhsKaryawan1.hitungNilaiAkhir());
        System.out.println("Grade: " + mhsKaryawan1.hitungGrade());

        System.out.println("\n============================\n");

        System.out.println(mhsKaryawan2.getMahasiswa());
        System.out.println("Nilai Akhir: " + mhsKaryawan2.hitungNilaiAkhir());
        System.out.println("Grade: " + mhsKaryawan2.hitungGrade());
    }
}