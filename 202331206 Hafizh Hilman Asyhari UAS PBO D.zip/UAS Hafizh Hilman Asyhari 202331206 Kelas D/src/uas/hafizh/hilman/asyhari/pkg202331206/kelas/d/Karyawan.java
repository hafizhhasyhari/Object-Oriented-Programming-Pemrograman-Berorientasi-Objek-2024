/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uas.hafizh.hilman.asyhari.pkg202331206.kelas.d;

/**
 *
 * @author HAFIZ
 */
// Subclass Karyawan
class Karyawan extends Mahasiswa {
        // Nama : Hafizh Hilman Asyhari
        // Kelas : D
        // Prodi : S1 Teknik Informatika
        // NIM : 202331206
        // Tanggal : 18 Januari 2025
        // UAS Pemrograman Berorientasi Objek
    
    private float nilaiPembimbing;
    private float nilaiPengetahuan;
    private float nilaiKeterampilan;

    public void setNilaiPembimbing(float nilaiPembimbing) {
        this.nilaiPembimbing = nilaiPembimbing;
    }

    public void setNilaiPengetahuan(float nilaiPengetahuan) {
        this.nilaiPengetahuan = nilaiPengetahuan;
    }

    public void setNilaiKeterampilan(float nilaiKeterampilan) {
        this.nilaiKeterampilan = nilaiKeterampilan;
    }

    @Override
    public float hitungNilaiAkhir() {
        return (0.3f * nilaiPembimbing) + (0.2f * nilaiPengetahuan) + (0.5f * nilaiKeterampilan);
    }
}