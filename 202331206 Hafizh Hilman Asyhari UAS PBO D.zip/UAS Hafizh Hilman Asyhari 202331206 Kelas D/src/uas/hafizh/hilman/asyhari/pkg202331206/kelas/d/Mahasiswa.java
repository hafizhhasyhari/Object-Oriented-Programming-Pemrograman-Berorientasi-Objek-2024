/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uas.hafizh.hilman.asyhari.pkg202331206.kelas.d;

/**
 *
 * @author Hafizh Hilman Asyhari
 */
// Abstract class Mahasiswa
abstract class Mahasiswa {
        // Nama : Hafizh Hilman Asyhari
        // Kelas : D
        // Prodi : S1 Teknik Informatika
        // NIM : 202331206
        // Tanggal : 18 Januari 2025
        // UAS Pemrograman Berorientasi Objek
    
    
    protected String nim;
    protected String nama;
    protected String prodi;

    public void setMahasiswa(String nim, String nama, String prodi) {
        this.nim = nim;
        this.nama = nama;
        this.prodi = prodi;
    }

    public String getMahasiswa() {
        return "NIM: " + nim + "\n" +
               "Nama: " + nama + "\n" +
               "Prodi: " + prodi + "\n";
    }

    public abstract float hitungNilaiAkhir();

    public String hitungGrade() {
        float nilaiAkhir = hitungNilaiAkhir();
        if (nilaiAkhir >= 80) return "A";
        else if (nilaiAkhir >= 70) return "B";
        else if (nilaiAkhir >= 55) return "C";
        else if (nilaiAkhir >= 45) return "D";
        else return "E";
    }
}